package br.com.bomdia

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.switchmaterial.SwitchMaterial
import java.time.LocalDate
import java.time.format.DateTimeFormatter

class SettingsActivity : AppCompatActivity() {

    private lateinit var prefs: Prefs
    private var morning = 0
    private var night = 0

    private val btnMorningTime by lazy { findViewById<MaterialButton>(R.id.btnMorningTime) }
    private val btnNightTime by lazy { findViewById<MaterialButton>(R.id.btnNightTime) }
    private val btnStart by lazy { findViewById<MaterialButton>(R.id.btnStart) }

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) sendTest() else toast("Notificações não permitidas. Use o botão de configurações do Android.")
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)
        prefs = Prefs(this)
        morning = savedInstanceState?.getInt("m") ?: prefs.morningMin
        night = savedInstanceState?.getInt("n") ?: prefs.nightMin

        findViewById<MaterialButton>(R.id.btnBack).setOnClickListener { finish() }

        // Tema
        val group = findViewById<RadioGroup>(R.id.rgTheme)
        group.check(
            when (prefs.theme) {
                1 -> R.id.rbLight
                2 -> R.id.rbDark
                else -> R.id.rbAuto
            }
        )
        group.setOnCheckedChangeListener { _, id ->
            val theme = when (id) {
                R.id.rbLight -> 1
                R.id.rbDark -> 2
                else -> 0
            }
            if (theme != prefs.theme) {
                prefs.theme = theme
                App.applyTheme(theme)
            }
        }

        // Lembretes
        val sw = findViewById<SwitchMaterial>(R.id.swReminders)
        sw.isChecked = prefs.remindersOn
        sw.setOnCheckedChangeListener { _, checked ->
            prefs.remindersOn = checked
            AlarmScheduler.scheduleAll(this)
        }
        btnMorningTime.setOnClickListener {
            TimePickerDialog(this, { _, h, m -> morning = h * 60 + m; refreshTimes() },
                morning / 60, morning % 60, true).show()
        }
        btnNightTime.setOnClickListener {
            TimePickerDialog(this, { _, h, m -> night = h * 60 + m; refreshTimes() },
                night / 60, night % 60, true).show()
        }
        findViewById<MaterialButton>(R.id.btnSave).setOnClickListener {
            prefs.morningMin = morning
            prefs.nightMin = night
            AlarmScheduler.scheduleAll(this)
            toast("Horários salvos")
        }
        findViewById<MaterialButton>(R.id.btnTest).setOnClickListener { testNotification() }
        findViewById<MaterialButton>(R.id.btnNotifSettings).setOnClickListener {
            startActivity(
                Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                    .putExtra(Settings.EXTRA_APP_PACKAGE, packageName)
            )
        }

        // Desafio
        btnStart.setOnClickListener {
            val current = LocalDate.ofEpochDay(prefs.startEpochDay)
            DatePickerDialog(this, { _, y, mo, d ->
                prefs.startEpochDay = LocalDate.of(y, mo + 1, d).toEpochDay()
                AlarmScheduler.scheduleAll(this)
                refreshTimes()
            }, current.year, current.monthValue - 1, current.dayOfMonth).show()
        }
        findViewById<MaterialButton>(R.id.btnReset).setOnClickListener {
            MaterialAlertDialogBuilder(this)
                .setTitle("Reiniciar progresso?")
                .setMessage("Os dias concluídos serão apagados. Horários, data inicial e tema continuam como estão.")
                .setPositiveButton("Reiniciar") { _, _ ->
                    prefs.resetProgress()
                    toast("Progresso reiniciado")
                }
                .setNegativeButton("Cancelar", null)
                .show()
        }

        refreshTimes()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putInt("m", morning)
        outState.putInt("n", night)
    }

    private fun fmt(min: Int) = "%02d:%02d".format(min / 60, min % 60)

    private fun refreshTimes() {
        btnMorningTime.text = "Bom dia: ${fmt(morning)}"
        btnNightTime.text = "Boa noite: ${fmt(night)}"
        btnStart.text = "Data inicial: " +
            LocalDate.ofEpochDay(prefs.startEpochDay).format(DateTimeFormatter.ofPattern("dd/MM/yyyy"))
    }

    private fun testNotification() {
        if (android.os.Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) !=
            android.content.pm.PackageManager.PERMISSION_GRANTED
        ) {
            permissionLauncher.launch(android.Manifest.permission.POST_NOTIFICATIONS)
            return
        }
        sendTest()
    }

    private fun sendTest() {
        if (!Notifier.canNotify(this)) {
            toast("As notificações estão desativadas para este app.")
            return
        }
        val state = Challenge.stateFor(LocalDate.ofEpochDay(prefs.startEpochDay), LocalDate.now())
        val day = if (state is Challenge.State.Running) state.day else 1
        Notifier.show(this, Notifier.KIND_MORNING, day, 98)
        toast("Notificação de teste enviada")
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
}
