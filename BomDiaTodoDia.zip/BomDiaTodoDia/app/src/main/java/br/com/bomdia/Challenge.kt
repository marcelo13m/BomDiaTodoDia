package br.com.bomdia

import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime
import java.time.temporal.ChronoUnit

object Challenge {
    const val TOTAL = 30
    val DEFAULT_START: LocalDate = LocalDate.of(2026, 10, 19)

    sealed class State {
        data class NotStarted(val daysLeft: Int) : State()
        data class Running(val day: Int) : State()
        object Finished : State()
    }

    fun stateFor(start: LocalDate, today: LocalDate): State {
        val offset = ChronoUnit.DAYS.between(start, today)
        return when {
            offset < 0 -> State.NotStarted((-offset).toInt())
            offset >= TOTAL -> State.Finished
            else -> State.Running(offset.toInt() + 1)
        }
    }

    fun endDate(start: LocalDate): LocalDate = start.plusDays((TOTAL - 1).toLong())

    /**
     * Próximo horário em que um lembrete deve tocar, ou null se o desafio já acabou.
     * Nunca devolve horário antes da data inicial nem depois do 30º dia.
     */
    fun nextTrigger(now: LocalDateTime, minuteOfDay: Int, start: LocalDate): LocalDateTime? {
        val time = LocalTime.of(minuteOfDay / 60, minuteOfDay % 60)
        var candidate = LocalDateTime.of(now.toLocalDate(), time)
        if (!candidate.isAfter(now)) candidate = candidate.plusDays(1)
        if (candidate.toLocalDate().isBefore(start)) candidate = LocalDateTime.of(start, time)
        if (candidate.toLocalDate().isAfter(endDate(start))) return null
        return candidate
    }
}
