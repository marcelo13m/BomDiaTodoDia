package br.com.bomdia

import android.content.Context

class Prefs(context: Context) {

    private val sp = context.applicationContext
        .getSharedPreferences("bomdia", Context.MODE_PRIVATE)

    /** 0 = automático, 1 = claro, 2 = escuro */
    var theme: Int
        get() = sp.getInt("theme", 0)
        set(v) = sp.edit().putInt("theme", v).apply()

    var startEpochDay: Long
        get() = sp.getLong("start", Challenge.DEFAULT_START.toEpochDay())
        set(v) = sp.edit().putLong("start", v).apply()

    var remindersOn: Boolean
        get() = sp.getBoolean("reminders", true)
        set(v) = sp.edit().putBoolean("reminders", v).apply()

    var morningMin: Int
        get() = sp.getInt("morning", 8 * 60)
        set(v) = sp.edit().putInt("morning", v).apply()

    var nightMin: Int
        get() = sp.getInt("night", 20 * 60 + 30)
        set(v) = sp.edit().putInt("night", v).apply()

    var askedNotifPermission: Boolean
        get() = sp.getBoolean("asked_notif", false)
        set(v) = sp.edit().putBoolean("asked_notif", v).apply()

    var done: Set<Int>
        get() = sp.getString("done", "")!!
            .split(",").mapNotNull { it.toIntOrNull() }.toSet()
        set(v) = sp.edit().putString("done", v.sorted().joinToString(",")).apply()

    fun toggleDone(day: Int) {
        val current = done.toMutableSet()
        if (!current.add(day)) current.remove(day)
        done = current
    }

    fun lastNotified(kind: Int): Long = sp.getLong("last_notified_$kind", -1L)

    fun setLastNotified(kind: Int, epochDay: Long) {
        sp.edit().putLong("last_notified_$kind", epochDay).apply()
    }

    /** Apaga só o progresso. Tema, horários e lembretes continuam como estão. */
    fun resetProgress() {
        sp.edit()
            .remove("done")
            .remove("last_notified_0")
            .remove("last_notified_1")
            .apply()
    }
}
