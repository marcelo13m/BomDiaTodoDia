package br.com.bomdia

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import java.time.LocalDate

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val kind = intent.getIntExtra(Notifier.EXTRA_KIND, Notifier.KIND_MORNING)
        val prefs = Prefs(context)
        val today = LocalDate.now()
        val state = Challenge.stateFor(LocalDate.ofEpochDay(prefs.startEpochDay), today)

        // Só notifica dentro dos 30 dias e no máximo uma vez por dia e por tipo.
        if (prefs.remindersOn && state is Challenge.State.Running &&
            prefs.lastNotified(kind) != today.toEpochDay()
        ) {
            prefs.setLastNotified(kind, today.toEpochDay())
            Notifier.show(context, kind, state.day, kind + 1)
        }
        AlarmScheduler.schedule(context, kind)
    }
}
