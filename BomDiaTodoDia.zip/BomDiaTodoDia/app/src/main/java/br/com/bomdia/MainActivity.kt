package br.com.bomdia

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.widget.GridLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.google.android.material.button.MaterialButton
import com.google.android.material.card.MaterialCardView
import com.google.android.material.progressindicator.LinearProgressIndicator
import java.time.LocalDate
import java.time.format.DateTimeFormatter

class MainActivity : AppCompatActivity() {

    private lateinit var prefs: Prefs
    private var selected = 1
    private var pendingScrollKind = -1

    private val scroll by lazy { findViewById<ScrollView>(R.id.scroll) }
    private val tvDay by lazy { findViewById<TextView>(R.id.tvDay) }
    private val tvSubtitle by lazy { findViewById<TextView>(R.id.tvSubtitle) }
    private val progress by lazy { findViewById<LinearProgressIndicator>(R.id.progress) }
    private val tvProgress by lazy { findViewById<TextView>(R.id.tvProgress) }
    private val tvSelected by lazy { findViewById<TextView>(R.id.tvSelected) }
    private val tvMorning by lazy { findViewById<TextView>(R.id.tvMorning) }
    private val tvNight by lazy { findViewById<TextView>(R.id.tvNight) }
    private val cardMorning by lazy { findViewById<MaterialCardView>(R.id.cardMorning) }
    private val cardNight by lazy { findViewById<MaterialCardView>(R.id.cardNight) }
    private val btnDone by lazy { findViewById<MaterialButton>(R.id.btnDone) }
    private val grid by lazy { findViewById<GridLayout>(R.id.calendarGrid) }

    private val notifPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    private val fmtDm = DateTimeFormatter.ofPattern("dd/MM")
    private val fmtDmy = DateTimeFormatter.ofPattern("dd/MM/yyyy")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        prefs = Prefs(this)

        selected = savedInstanceState?.getInt("sel") ?: initialSelection()
        handleIntent(intent)

        findViewById<MaterialButton>(R.id.btnCopyMorning).setOnClickListener { copy(Messages.morning(selected)) }
        findViewById<MaterialButton>(R.id.btnShareMorning).setOnClickListener { share(Messages.morning(selected)) }
        findViewById<MaterialButton>(R.id.btnCopyNight).setOnClickListener { copy(Messages.night(selected)) }
        findViewById<MaterialButton>(R.id.btnShareNight).setOnClickListener { share(Messages.night(selected)) }
        findViewById<MaterialButton>(R.id.btnSettings).setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }
        btnDone.setOnClickListener {
            prefs.toggleDone(selected)
            render()
        }

        AlarmScheduler.scheduleAll(this)
        askNotificationPermissionOnce()
    }

    override fun onResume() {
        super.onResume()
        render()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
        render()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putInt("sel", selected)
    }

    private fun initialSelection(): Int {
        val state = Challenge.stateFor(LocalDate.ofEpochDay(prefs.startEpochDay), LocalDate.now())
        return when (state) {
            is Challenge.State.Running -> state.day
            is Challenge.State.NotStarted -> 1
            is Challenge.State.Finished -> Challenge.TOTAL
        }
    }

    private fun handleIntent(intent: Intent?) {
        if (intent == null || !intent.hasExtra(Notifier.EXTRA_DAY)) return
        selected = intent.getIntExtra(Notifier.EXTRA_DAY, 1).coerceIn(1, Challenge.TOTAL)
        pendingScrollKind = intent.getIntExtra(Notifier.EXTRA_KIND, -1)
        intent.removeExtra(Notifier.EXTRA_DAY)
        intent.removeExtra(Notifier.EXTRA_KIND)
    }

    private fun askNotificationPermissionOnce() {
        if (Build.VERSION.SDK_INT >= 33 && !prefs.askedNotifPermission &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            prefs.askedNotifPermission = true
            notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    private fun render() {
        val start = LocalDate.ofEpochDay(prefs.startEpochDay)
        val today = LocalDate.now()
        val state = Challenge.stateFor(start, today)
        val range = "Desafio de ${start.format(fmtDmy)} a ${Challenge.endDate(start).format(fmtDmy)}"

        when (state) {
            is Challenge.State.NotStarted -> {
                tvDay.text = if (state.daysLeft == 1) "Começa amanhã" else "Começa em ${state.daysLeft} dias"
                tvSubtitle.text = range
            }
            is Challenge.State.Running -> {
                tvDay.text = "Dia ${state.day} de ${Challenge.TOTAL}"
                tvSubtitle.text = range
            }
            is Challenge.State.Finished -> {
                tvDay.text = "Desafio concluído! 🎉"
                tvSubtitle.text = "Parabéns pelos 30 dias! Os lembretes foram encerrados. $range"
            }
        }

        val done = prefs.done
        val percent = done.size * 100 / Challenge.TOTAL
        progress.setProgressCompat(percent, true)
        tvProgress.text = "${done.size} de ${Challenge.TOTAL} dias concluídos ($percent%)"

        val selDate = start.plusDays((selected - 1).toLong())
        tvSelected.text = "Mensagens do dia $selected • ${selDate.format(fmtDm)}" +
            if (selDate == today) " (hoje)" else ""
        tvMorning.text = Messages.morning(selected)
        tvNight.text = Messages.night(selected)

        if (selDate.isAfter(today)) {
            btnDone.isEnabled = false
            btnDone.text = "Disponível em ${selDate.format(fmtDm)}"
        } else {
            btnDone.isEnabled = true
            btnDone.text = if (selected in done) "Desmarcar o dia $selected"
            else "Marcar o dia $selected como concluído"
        }

        renderCalendar(start, today, done)

        if (pendingScrollKind >= 0) {
            val target = if (pendingScrollKind == Notifier.KIND_NIGHT) cardNight else cardMorning
            pendingScrollKind = -1
            scroll.post { scroll.smoothScrollTo(0, target.top) }
        }
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
    private fun color(id: Int): Int = ContextCompat.getColor(this, id)

    private fun renderCalendar(start: LocalDate, today: LocalDate, done: Set<Int>) {
        grid.removeAllViews()
        for (d in 1..Challenge.TOTAL) {
            val date = start.plusDays((d - 1).toLong())
            val isDone = d in done
            val isToday = date == today
            val isSel = d == selected

            val cell = TextView(this).apply {
                text = "$d\n${date.format(fmtDm)}"
                gravity = Gravity.CENTER
                textSize = 12f
                setTextColor(color(if (isDone) R.color.on_accent else R.color.text))
                background = GradientDrawable().apply {
                    cornerRadius = dp(12).toFloat()
                    setColor(color(if (isDone) R.color.accent else R.color.chip))
                    when {
                        isSel -> setStroke(dp(3), color(R.color.text))
                        isToday -> setStroke(dp(2), color(R.color.gold))
                        else -> setStroke(dp(1), color(R.color.outline))
                    }
                }
                contentDescription = "Dia $d, ${date.format(fmtDm)}" + if (isDone) ", concluído" else ""
                setOnClickListener {
                    selected = d
                    render()
                }
            }
            val lp = GridLayout.LayoutParams(
                GridLayout.spec(GridLayout.UNDEFINED),
                GridLayout.spec(GridLayout.UNDEFINED, 1f)
            ).apply {
                width = 0
                height = dp(58)
                setMargins(dp(3), dp(3), dp(3), dp(3))
            }
            grid.addView(cell, lp)
        }
    }

    private fun copy(text: String) {
        val clipboard = getSystemService(ClipboardManager::class.java)
        clipboard.setPrimaryClip(ClipData.newPlainText("mensagem", text))
        Toast.makeText(this, "Mensagem copiada", Toast.LENGTH_SHORT).show()
    }

    private fun share(text: String) {
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, text)
        }
        startActivity(Intent.createChooser(send, "Compartilhar mensagem"))
    }
}
