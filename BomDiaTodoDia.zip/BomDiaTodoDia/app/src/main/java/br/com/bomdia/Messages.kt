package br.com.bomdia

object Messages {

    val MORNING: List<String> = listOf(
        "Bom dia! Que o seu dia comece leve e cheio de boas surpresas. ☀️",
        "Bom dia! Desejo uma manhã tranquila e um dia gostoso pela frente.",
        "Bom dia! Passando para desejar muita paz e boas conversas hoje.",
        "Bom dia! Que as pequenas coisas lhe tragam alegria hoje. Tenha um ótimo dia!",
        "Bom dia! Espero que o café esteja quentinho e a manhã seja serena. ☕",
        "Bom dia! Que tudo corra bem e sem pressa hoje. Um abraço!",
        "Bom dia! Desejo que você encontre motivos para sorrir ao longo do dia. 🙂",
        "Bom dia! Que este dia traga boas notícias e muita tranquilidade.",
        "Bom dia! Que nada atrapalhe a sua manhã e que tudo flua com calma.",
        "Bom dia! Comecei o dia com um pensamento bom para você. Tenha um dia lindo! 🌿",
        "Bom dia! Que hoje venham encontros agradáveis e momentos de descanso.",
        "Bom dia, tudo bem? Desejo um dia produtivo e, principalmente, tranquilo.",
        "Bom dia! Que a luz da manhã acompanhe você em tudo o que fizer hoje.",
        "Bom dia! Respire fundo, beba uma água e vá com calma. Boa manhã para você! 💧",
        "Bom dia! Que haja tempo para o que importa e leveza para o resto.",
        "Bom dia! Torço para que hoje seja um dia de boas surpresas e pouco estresse.",
        "Bom dia! Desejo que a sua manhã seja bonita e o seu dia, gentil.",
        "Bom dia! Que você receba hoje uma boa notícia e uma conversa agradável.",
        "Bom dia! Que tudo o que for importante hoje se resolva com tranquilidade.",
        "Bom dia! Mais uma manhã chegando: que ela seja boa para você e para os seus.",
        "Bom dia! Que o seu caminho hoje seja cheio de gente simpática e boas ideias.",
        "Bom dia! Passando só para dizer que pensei em você. Tenha um dia ótimo! 😊",
        "Bom dia! Que você ache hoje um tempinho para fazer algo de que gosta.",
        "Bom dia! Desejo disposição para as tarefas e calma para os imprevistos.",
        "Bom dia! Que o céu esteja bonito aí e o seu humor, ainda melhor. 🌤️",
        "Bom dia! Que cada hora de hoje traga um motivo pequeno para agradecer.",
        "Bom dia! Que todos tratem você bem hoje, como você merece.",
        "Bom dia! Que haja bom humor na ida, na volta e paz no meio do caminho.",
        "Bom dia! Que a sua manhã tenha um começo suave e um final ainda melhor.",
        "Bom dia! Que o seu dia seja tão bom quanto a gentileza que você oferece aos outros. 🌻"
    )

    val NIGHT: List<String> = listOf(
        "Boa noite! Que você descanse bem e acorde com a energia renovada. 🌙",
        "Boa noite! Desejo uma noite tranquila e um sono bem gostoso.",
        "Boa noite! Que o dia termine em paz e a noite seja de descanso.",
        "Boa noite! Agora é hora de desacelerar. Durma bem e até amanhã!",
        "Boa noite! Que os pensamentos se aquietem e o sono chegue fácil.",
        "Boa noite! Foi um dia cheio, e você merece uma noite de descanso de verdade.",
        "Boa noite! Que o silêncio da noite faça bem a você. Durma com tranquilidade. ✨",
        "Boa noite! Espero que você tenha tido um bom dia. Descanse bastante!",
        "Boa noite! Que o cansaço de hoje vire disposição amanhã.",
        "Boa noite! Que o seu travesseiro seja macio e a sua noite, serena.",
        "Boa noite! Hora de desligar um pouco do mundo e cuidar do descanso. 😴",
        "Boa noite! Que você durma em paz e sonhe com coisas boas.",
        "Boa noite! Que as preocupações fiquem para amanhã e a noite seja só de calma.",
        "Boa noite! Termine o dia com a sensação de dever cumprido. Bom descanso!",
        "Boa noite! Que a lua traga uma noite suave para você. 🌛",
        "Boa noite! Respire fundo, relaxe e deixe o sono vir sem pressa.",
        "Boa noite! Que o descanso de hoje recarregue as suas energias para o que vem.",
        "Boa noite! Que você feche o dia com algo bom na memória e durma tranquilo.",
        "Boa noite! Que a casa esteja quietinha e o sono, profundo.",
        "Boa noite! Mais um dia vivido. Que a noite seja de repouso e gratidão.",
        "Boa noite! Que nada atrapalhe o seu sono e que o amanhecer seja gentil. 🌌",
        "Boa noite! Desejo uma noite fresquinha, silenciosa e cheia de descanso.",
        "Boa noite! Permita-se parar um pouco. Descanse sem culpa.",
        "Boa noite! Que as estrelas cuidem do seu sono hoje. Até amanhã! ⭐",
        "Boa noite! Que amanhã você comece o dia com o corpo descansado e a mente leve.",
        "Boa noite! Fecho o dia desejando que você durma bem e acorde bem-disposto.",
        "Boa noite! Que a tranquilidade desta hora acompanhe você até de manhã.",
        "Boa noite! Hoje o melhor a fazer é descansar. Tenha um sono reparador.",
        "Boa noite! Que você termine o dia com um sorriso e adormeça em paz. 🙂",
        "Boa noite! Obrigado pela atenção de sempre. Durma bem e tenha bons sonhos! 💤"
    )

    private fun pick(list: List<String>, day: Int): String =
        list[(day - 1).coerceIn(0, list.size - 1)]

    fun morning(day: Int): String = pick(MORNING, day)
    fun night(day: Int): String = pick(NIGHT, day)
}
