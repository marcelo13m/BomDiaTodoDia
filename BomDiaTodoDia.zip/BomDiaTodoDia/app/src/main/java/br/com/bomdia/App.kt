package br.com.bomdia

import android.app.Application
import androidx.appcompat.app.AppCompatDelegate

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        applyTheme(Prefs(this).theme)
        Notifier.ensureChannel(this)
    }

    companion object {
        fun applyTheme(theme: Int) {
            AppCompatDelegate.setDefaultNightMode(
                when (theme) {
                    1 -> AppCompatDelegate.MODE_NIGHT_NO
                    2 -> AppCompatDelegate.MODE_NIGHT_YES
                    else -> AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM
                }
            )
        }
    }
}
