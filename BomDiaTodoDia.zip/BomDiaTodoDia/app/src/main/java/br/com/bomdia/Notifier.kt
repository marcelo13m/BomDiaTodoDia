package br.com.bomdia

import android.Manifest
import android.annotation.SuppressLint
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat

object Notifier {
    const val CHANNEL = "lembretes"
    const val EXTRA_KIND = "kind"
    const val EXTRA_DAY = "day"
    const val KIND_MORNING = 0
    const val KIND_NIGHT = 1

    fun ensureChannel(ctx: Context) {
        val channel = NotificationChannel(
            CHANNEL, "Lembretes diários", NotificationManager.IMPORTANCE_DEFAULT
        ).apply { description = "Lembretes de bom dia e boa noite" }
        ctx.getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
    }

    fun canNotify(ctx: Context): Boolean {
        if (!NotificationManagerCompat.from(ctx).areNotificationsEnabled()) return false
        if (Build.VERSION.SDK_INT >= 33 &&
            ctx.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) return false
        return true
    }

    @SuppressLint("MissingPermission")
    fun show(ctx: Context, kind: Int, day: Int, id: Int) {
        ensureChannel(ctx)
        if (!canNotify(ctx)) return

        val open = Intent(ctx, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or
                Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra(EXTRA_KIND, kind)
            putExtra(EXTRA_DAY, day)
        }
        val pending = PendingIntent.getActivity(
            ctx, 100 + kind, open,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val title = if (kind == KIND_MORNING) "Hora de desejar bom dia!" else "Hora de desejar boa noite!"
        val text = if (kind == KIND_MORNING) Messages.morning(day) else Messages.night(day)

        val notification = NotificationCompat.Builder(ctx, CHANNEL)
            .setSmallIcon(R.drawable.ic_notif)
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setContentIntent(pending)
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .build()
        NotificationManagerCompat.from(ctx).notify(id, notification)
    }
}
