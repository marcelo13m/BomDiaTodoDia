package br.com.bomdia

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.ZoneId

object AlarmScheduler {

    private fun pending(ctx: Context, kind: Int): PendingIntent {
        val intent = Intent(ctx, AlarmReceiver::class.java).putExtra(Notifier.EXTRA_KIND, kind)
        return PendingIntent.getBroadcast(
            ctx, kind, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    /** Agenda (ou cancela) o próximo lembrete de um tipo. Alarme inexato: não exige permissão especial. */
    fun schedule(ctx: Context, kind: Int) {
        val prefs = Prefs(ctx)
        val am = ctx.getSystemService(AlarmManager::class.java)
        val pi = pending(ctx, kind)
        val minutes = if (kind == Notifier.KIND_MORNING) prefs.morningMin else prefs.nightMin
        val trigger = Challenge.nextTrigger(
            LocalDateTime.now(), minutes, LocalDate.ofEpochDay(prefs.startEpochDay)
        )
        if (!prefs.remindersOn || trigger == null) {
            am.cancel(pi)
            return
        }
        val millis = trigger.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()
        am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, millis, pi)
    }

    fun scheduleAll(ctx: Context) {
        schedule(ctx, Notifier.KIND_MORNING)
        schedule(ctx, Notifier.KIND_NIGHT)
    }
}
