package br.com.bomdia

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class MessagesTest {
    @Test fun temTrintaDeCada() {
        assertEquals(30, Messages.MORNING.size)
        assertEquals(30, Messages.NIGHT.size)
    }

    @Test fun naoHaRepeticaoDentroDeCadaCategoria() {
        assertEquals(30, Messages.MORNING.toSet().size)
        assertEquals(30, Messages.NIGHT.toSet().size)
    }

    @Test fun nenhumaMensagemVazia() {
        assertTrue((Messages.MORNING + Messages.NIGHT).all { it.isNotBlank() })
    }

    @Test fun mensagemSegueODia() {
        assertEquals(Messages.MORNING[0], Messages.morning(1))
        assertEquals(Messages.NIGHT[29], Messages.night(30))
    }
}
