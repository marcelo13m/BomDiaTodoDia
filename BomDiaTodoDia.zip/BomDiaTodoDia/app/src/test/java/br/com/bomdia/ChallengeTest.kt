package br.com.bomdia

import java.time.LocalDate
import java.time.LocalDateTime
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class ChallengeTest {
    private val start = LocalDate.of(2026, 10, 19)

    @Test fun antesDoInicio() {
        assertEquals(Challenge.State.NotStarted(1), Challenge.stateFor(start, LocalDate.of(2026, 10, 18)))
    }

    @Test fun primeiroEUltimoDia() {
        assertEquals(Challenge.State.Running(1), Challenge.stateFor(start, start))
        assertEquals(Challenge.State.Running(30), Challenge.stateFor(start, LocalDate.of(2026, 11, 17)))
    }

    @Test fun depoisDoFim() {
        assertEquals(Challenge.State.Finished, Challenge.stateFor(start, LocalDate.of(2026, 11, 18)))
    }

    @Test fun viradaDeAno() {
        val s = LocalDate.of(2026, 12, 20)
        assertEquals(LocalDate.of(2027, 1, 18), Challenge.endDate(s))
        assertEquals(Challenge.State.Running(30), Challenge.stateFor(s, LocalDate.of(2027, 1, 18)))
    }

    @Test fun lembreteAntesDoInicioVaiParaDataInicial() {
        val t = Challenge.nextTrigger(LocalDateTime.of(2026, 10, 10, 12, 0), 8 * 60, start)
        assertEquals(LocalDateTime.of(2026, 10, 19, 8, 0), t)
    }

    @Test fun lembreteJaPassadoHojeVaiParaAmanha() {
        val t = Challenge.nextTrigger(LocalDateTime.of(2026, 10, 20, 9, 0), 8 * 60, start)
        assertEquals(LocalDateTime.of(2026, 10, 21, 8, 0), t)
    }

    @Test fun ultimoDiaAntesDoHorarioAindaToca() {
        val t = Challenge.nextTrigger(LocalDateTime.of(2026, 11, 17, 7, 0), 20 * 60 + 30, start)
        assertEquals(LocalDateTime.of(2026, 11, 17, 20, 30), t)
    }

    @Test fun depoisDoTrigesimoDiaNaoHaLembrete() {
        assertNull(Challenge.nextTrigger(LocalDateTime.of(2026, 11, 17, 21, 0), 20 * 60 + 30, start))
        assertNull(Challenge.nextTrigger(LocalDateTime.of(2026, 12, 1, 7, 0), 8 * 60, start))
    }
}
